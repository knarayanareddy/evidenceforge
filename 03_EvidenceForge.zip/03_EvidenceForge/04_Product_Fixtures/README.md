# Fixture scope

These are unchanged synthetic baseline fixtures. PDF and evidence regions are synthetic authored fixtures, not actual Docling output.

Canonical generators, reference oracles and tests remain in ../05_Shared_Baseline.
