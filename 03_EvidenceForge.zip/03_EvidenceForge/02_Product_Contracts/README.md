# EvidenceForge: scoped contracts

Contains 21 domain operations (12 product-specific plus shared foundation), 24 standalone schemas with recursive dependencies, structural examples and four UI workflow screens. Schema objects embedded in OpenAPI are also retained by reference closure. Browser identity and health routes are separately defined in auth-flow.yaml.

These are extracted views, not a new contract revision. Do not independently modify these copies. Make reviewed changes in the canonical 05_Shared_Baseline, regenerate it, then regenerate organizational views. Canonical SQL and executable tests are preserved there intact.
